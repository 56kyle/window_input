# window_input
 A set of tools for interacting with windows, including those that are non foreground and even minimized.


### Installation
    pip install window_input

### Recommended Usage
    from window_input import Window, Key
    
### Examples

    from window_input import Window, Key
    
    if __name__ == "__main__":
        TODO
